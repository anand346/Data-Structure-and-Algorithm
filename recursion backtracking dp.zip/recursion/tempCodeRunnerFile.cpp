
    cout<<"enter no."<<endl;
    cin>>n;
    cout<<"digits. are : "<<count(n);