// https://www.youtube.com/watch?v=bzgH0ASZ87Y

#include<bits/stdc++.h>
using namespace std;


int main(){

    int n;
    cin>>n;
    cout<<(n | n+1)<<endl;
}