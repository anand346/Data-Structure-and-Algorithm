#include<bits/stdc++.h>
using namespace std;


int main(){

    int n = 6;
    if(n&1 == 1){
        cout<<"odd num"<<endl;
    }else{
        cout<<"Even num"<<endl;
    }
}